# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['manim_code']

package_data = \
{'': ['*']}

install_requires = \
['manimce>=0.1.0,<0.2.0']

entry_points = \
{'manim.plugins': ['manim_code = manim_code']}

setup_kwargs = {
    'name': 'manim-code',
    'version': '0.1.0',
    'description': 'Manim extension designed for code explanatory videos',
    'long_description': 'Advanced Code Extensions\n------------------------\n\nThis Manim extension allows you to quickly create arrays, assign elements, point to elements, push, pop and etc. It sits on top of the `Manim Community Edition <https://github.com/ManimCommunity/manim>`_.\n\nOverview:\n - Array\n\nIn the works:\n - Code Highlighting by text search\n\nTODO:\n - Make the array flexible i.e. each element with different Rectangles\n - 2D Array, maybe even 3D arrays\n - Stack\n - Tests\n\nArray\n~~~~~\n\nThe Array object has many functionalities. It creates a Rectangle and Tex object for each element, also it creates a Tex object for its name.\n\nExample code:\n\n .. code-block:: python\n\n    arr = [0, 1, 2, 3, 4, 5]\n\n    arr_obj = Array("array:", len(arr), values = arr, name_config = {\n        "fill_color": WHITE\n    })\n\n    arr_obj.create_array(sq_size = 0.5, text_size = 1.2)\n    arr_obj.draw_array(self.play, run_time = 0.5)\n    \n    # create i pointer\n    arr_obj.create_pointer("i", 2)\n    arr_obj.draw_pointer("i", self.play, run_time = 0.5)\n    arr_obj.draw_pointer_name("i", "i", self.play, run_time = 0.5)\n    \n    # this gets the pointer but not the name object\n    pointer = arr_obj.get_pointer("i")\n    # while shifting the pointer to specific square\n    # it shifts the name also\n    self.play(\n        pointer.next_to, arr_obj.get_square(4), DOWN, \n        run_time = 0.5\n    )\n    \n    arr_obj.indicate_at(4, self.play, run_time = 0.5)\n    self.play(Indicate(arr_obj.get_pointer("i"), run_time = 0.5))\n    self.play(arr_obj.scale, 1.1, run_time = 0.5)\n\n    # pop the element with index 3\n    arr_obj.pop(3, self.play)\n\n    self.wait(1)\n\nFunctions\n^^^^^^^^^\n\ncreate_array (sq_size: `int`, text_size: `int`)\n    Creates all the necessary objects with the given text and square size.\n\ndraw_array (play, `**config`)\n    Draws the array on the screen. You need to pass the self.play function, so the array object can call it.\n\npop (index: `int`, play, `**config`)\n    Animation of poping an element from the array. It deletes the objects associated with it, but not the pointers. It shifts all the other elements appropriately.\n\nget_square (index: `int`)\n    Gets the Square object of an element with the given index.\n\nPointers to elements\n^^^^^^^^^^^^^^^^^^^^\n\ncreate_pointer (name: `str`, index: `int`)\n    Creates a pointer to an element with the given `index`. Each pointer has a unique name. The pointer is a Vector object.\n\ndraw_pointer(name, play, `**config`)\n    Draws the pointer.\n\ndraw_pointer_name(name: `str`, text: `str`, play, `**config`)\n    Draw a `text` below a pointer with the given `name`.\n\nget_pointer(name: `str`)\n    Gets the pointer\'s Vector object.\n\n----------\n\nContributing\n~~~~~~~~~~~~\n\nFeel free to contribute and suggest new features! The plans for the future are to make the array much more flexible and create different representations, such as 2D and 3D arrays, stacks, etc.',
    'author': 'Mitko Nikov',
    'author_email': 'mitkonikov01@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
