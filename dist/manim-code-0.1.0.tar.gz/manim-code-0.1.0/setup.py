# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['manim_code']

package_data = \
{'': ['*']}

install_requires = \
['manimce>=0.1.0,<0.2.0']

entry_points = \
{'manim.plugins': ['manim_code = manim_code']}

setup_kwargs = {
    'name': 'manim-code',
    'version': '0.1.0',
    'description': 'Manim extension designed for code explanatory videos',
    'long_description': 'Advanced Code Extensions\n------------------------\n\nThis Manim extension allows you to quickly create arrays, assign elements, point to elements, push, pop and etc.\n\nOverview:\n - Array\n - Code Highlighting by text search\n\nTODO:\n - Queue\n - Stack\n\nArray\n~~~~~\n\nThe Array object has many functionalities. It creates a Rectangle and Tex object for each element, also it creates a Tex object for its name.\n\nExample code:\n .. code-block:: python\n\n    arr = [0, 1, 2, 3, 4, 5]\n\n    arr_obj = Array("array:", len(arr), values = arr, name_config = {\n        "fill_color": WHITE\n    })\n\n    arr_obj.create_array(sq_size = 0.5, text_size = 1.2)\n    arr_obj.draw_array(self.play, run_time = 0.5)\n    \n    # create i pointer\n    arr_obj.create_pointer("i", 2)\n    arr_obj.draw_pointer("i", self.play, run_time = 0.5)\n    arr_obj.draw_pointer_name("i", "i", self.play, run_time = 0.5)\n    \n    # this gets the pointer but not the name object\n    pointer = arr_obj.get_pointer("i")\n    # while shifting the pointer to specific square\n    # it shifts the name also\n    self.play(\n        pointer.next_to, arr_obj.get_square(4), DOWN, \n        run_time = 0.5\n    )\n    \n    arr_obj.indicate_at(4, self.play, run_time = 0.5)\n    self.play(Indicate(arr_obj.get_pointer("i"), run_time = 0.5))\n    self.play(arr_obj.scale, 1.1, run_time = 0.5)',
    'author': 'Mitko Nikov',
    'author_email': 'mitkonikov01@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
